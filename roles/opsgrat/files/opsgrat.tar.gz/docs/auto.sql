-- ------------------------ project模块 ------------------------ --
-- 凭据表
DROP TABLE IF EXISTS `credential`;
CREATE TABLE `credential` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '凭据名称',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '凭据类型：ssh-ssh；user_pwd-用户名密码；ansible_vault-Ansible Vault；aliyun_accesskey-阿里云AccessKey',
  `user_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户名',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '密码',
  `private_key` text COLLATE utf8mb4_unicode_ci COMMENT 'ssh私钥',
  `passphrase` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'ssh私钥密码',
  `become_method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '切换方式:sudo；su；pbrun',
  `become_user` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '切换用户',
  `become_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '切换密码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='凭据表';

-- inventory表
DROP TABLE IF EXISTS `inventory`;
CREATE TABLE `inventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `variables` text COLLATE utf8mb4_unicode_ci COMMENT '参数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='主机清单表';

-- 主机表
DROP TABLE IF EXISTS `host`;
CREATE TABLE `host` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hostname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '主机名',
  `inventory_id` int(11) DEFAULT NULL COMMENT 'inventory id',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态：1-启用；2-禁用',
  `variables` text COLLATE utf8mb4_unicode_ci COMMENT '参数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='主机表';

-- group表
DROP TABLE IF EXISTS `group`;
CREATE TABLE `group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `inventory_id` int(11) DEFAULT NULL COMMENT 'inventory id',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `variables` text COLLATE utf8mb4_unicode_ci COMMENT '参数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='group表';

-- group关联表
DROP TABLE IF EXISTS `group_children`;
CREATE TABLE `group_children` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT NULL COMMENT '组id',
  `child_id` int(11) DEFAULT NULL COMMENT '组id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_child` (`group_id`, `child_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='group关联表';

-- group主机表
DROP TABLE IF EXISTS `group_hosts`;
CREATE TABLE `group_hosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT NULL COMMENT '组id',
  `host_id` int(11)  DEFAULT NULL COMMENT '主机id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_host` (`group_id`, `host_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='group主机表';

DROP TABLE IF EXISTS `project`;
CREATE TABLE `project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `git` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'git仓库地址',
  `branch_specifier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '分支/Tag',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='自动化工程';

-- ------------------------ project模块 ------------------------ --

-- ------------------------ notification模块 ------------------------ --

DROP TABLE IF EXISTS `notification`;
CREATE TABLE `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '通知名称',
  `channel` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Alarm' COMMENT '渠道：WebHook-WebHook；Email-邮件；DingTalk-钉钉',
  `channel_id` int(11)  COMMENT '渠道ID',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `target_list` text COLLATE utf8mb4_unicode_ci COMMENT '通知目标',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='通知设置';

DROP TABLE IF EXISTS `notification_webhook`;
DROP TABLE IF EXISTS `notification_email`;
DROP TABLE IF EXISTS `notification_dingtalk`;

DROP TABLE IF EXISTS `email_setting`;
CREATE TABLE `email_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email_host` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '邮件网关',
  `email_port` int(11) NOT NULL DEFAULT '465' COMMENT '邮件端口',
  `email_user` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户名',
  `email_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '密码',
  `email_tls` int(11) NOT NULL DEFAULT '0' COMMENT '是否是tsl: 0-是，1-否',
  `email_ssl` int(11) NOT NULL DEFAULT '0' COMMENT '是否是ssh: 0-是，1-否',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='邮件设置';

DROP TABLE IF EXISTS `dingtalk_setting`;
CREATE TABLE `dingtalk_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `agent_id` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'AgentID',
  `corpid` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'CorpId',
  `corpsecret` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'CorpSecret',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='钉钉设置';

-- ------------------------ notification模块 ------------------------ --

-- ------------------------ job模块 ------------------------ --

-- 工作任务表
DROP TABLE IF EXISTS `job`;
CREATE TABLE `job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) DEFAULT NULL COMMENT '父任务ID',
  `kind` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'job' COMMENT '任务类型：job；workflow；command',
  `cuser` int(11)  NOT NULL DEFAULT '0' COMMENT '执行用户',
  `template_id` int(11) DEFAULT NULL COMMENT '模板id',
  `job_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'job类型:run-Run;check-Check',
  `inventory_id` int(11)  DEFAULT NULL COMMENT 'inventory id',
  `credential_id` int(11) DEFAULT NULL COMMENT '凭据id',
  `playbook` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'playbook',
  `forks` int(11) NOT NULL DEFAULT '1' COMMENT 'forks',
  `limit` text COLLATE utf8mb4_unicode_ci COMMENT 'limit',
  `tags` text COLLATE utf8mb4_unicode_ci COMMENT 'tags',
  `skip_tags` text COLLATE utf8mb4_unicode_ci COMMENT 'skip tags',
  `verbosity` tinyint(3) NOT NULL DEFAULT '0' COMMENT 'Debug级别：0-Normal；1-Verbose；2-More Verbose；3-Debug；4-Connection Debug',
  `variables` text COLLATE utf8mb4_unicode_ci COMMENT '扩展参数',
  `state` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new' COMMENT '运行结果：new-新建；waiting-等待中；running-运行中；successful-成功；failure-失败',
  `start_time` bigint(20) NOT NULL DEFAULT 0 COMMENT '开始时间',
  `finish_time` bigint(20) NOT NULL DEFAULT 0 COMMENT '完成时间',
  `inventory_str` mediumtext COLLATE utf8mb4_unicode_ci COMMENT 'inventory',
  `become_enabled` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否允许切换用户:0-否；1-是',
  `diff_mode` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否使用diff模块:0-否；1-是',
  `force_handlers` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否强制运行handlers任务:0-否；1-是',
  `start_at_task` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '开始任务',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工作任务表';

-- 工作任务日志表
DROP TABLE IF EXISTS `job_log`;
CREATE TABLE `job_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) DEFAULT NULL COMMENT '任务id',
  `ctime` bigint(20) NOT NULL DEFAULT 0 COMMENT '创建时间',
  `log` mediumtext COLLATE utf8mb4_unicode_ci COMMENT '执行日志',
  PRIMARY KEY (`id`),
  KEY `job_id` (`job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='任务日志表';

DROP TABLE IF EXISTS `schedule`;
CREATE TABLE `schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '任务名称',
  `template_id` int(11) DEFAULT NULL COMMENT '模板id',
  `type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cron' COMMENT '执行方式：cron-计划任务；interval-固定间隔；date-特定时间(只执行一次)',
  `start_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '开始时间',
  `minute` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '分',
  `hour` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '时',
  `day` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '日',
  `month` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '月',
  `week` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '周',
  `interval_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'seconds' COMMENT '间隔类型：seconds-秒；minutes-分钟；hours-小时；days-天；weeks-周',
  `interval` int(11) NOT NULL DEFAULT 0 COMMENT '间隔时间',
  `timezone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '时区',
  `end_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '结束时间',
  `last_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后执行时间',
  `next_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '下次执行时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='计划任务表';

-- ------------------------ job模块 ------------------------ --

-- ------------------------ template模块 ------------------------ --

-- 模板表
DROP TABLE IF EXISTS `template`;
CREATE TABLE `template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '模板名称',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `template_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Job' COMMENT '模板类型:job-Job；workflow-Workflow',
  `job_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'job类型:run-Run;check-Check',
  `inventory_id` int(11) DEFAULT NULL COMMENT 'inventory id',
  `project_id` int(11) DEFAULT NULL COMMENT '自动化工程id',
  `playbook` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'playbook',
  `credential_id` int(11) DEFAULT NULL COMMENT '凭据id',
  `forks` int(11) NOT NULL DEFAULT '0' COMMENT 'forks',
  `limit` text COLLATE utf8mb4_unicode_ci COMMENT 'limit',
  `tags` text COLLATE utf8mb4_unicode_ci COMMENT 'tags',
  `skip_tags` text COLLATE utf8mb4_unicode_ci COMMENT 'skip tags',
  `verbosity` tinyint(3) NOT NULL DEFAULT '0' COMMENT 'Debug级别：0-Normal；1-Verbose；2-More Verbose；3-Debug；4-Connection Debug',
  `variables` text COLLATE utf8mb4_unicode_ci COMMENT '扩展参数',
  `become_enabled` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否允许切换用户:0-否；1-是',
  `diff_mode` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否使用diff模块:0-否；1-是',
  `force_handlers` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否强制运行handlers任务:0-否；1-是',
  `start_at_task` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '开始任务',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='自动化模板';

-- 模板通知设置
DROP TABLE IF EXISTS `template_notification`;
CREATE TABLE `template_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) DEFAULT NULL COMMENT '模板id',
  `notification_id` int(11) NOT NULL DEFAULT '0' COMMENT '通知id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='模板通知表';

-- 工作流节点表
DROP TABLE IF EXISTS `workflow_node`;
CREATE TABLE `workflow_node` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '节点名称',
  `template_id` int(11) DEFAULT NULL COMMENT '模板id',
  `is_start_node` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否开始节点：0-否；1-是',
  `left` int(11) NOT NULL COMMENT '距离左边位置',
  `top` int(11) NOT NULL COMMENT '距离顶部位置',
  `type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'template' COMMENT '节点类型: Template; Workflow',
  `bind_template_id` int(11) DEFAULT NULL COMMENT '绑定模板id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工作流节点表';


-- 工作流连线表
DROP TABLE IF EXISTS `workflow_line`;
CREATE TABLE `workflow_line` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `node_id` int(11) DEFAULT NULL COMMENT '节点ID',
  `next_node_id` int(11) DEFAULT NULL COMMENT '下个节点ID',
  `source_anchor` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '起始连线位置',
  `target_anchor` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '终止连线位置',
  `result` varchar(30) NOT NULL DEFAULT 'any' COMMENT '运行结果：any-任意；successful-成功；failure-失败',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工作流连线表';

-- ------------------------ template模块 ------------------------ --



-- ------------------------ dashboard模块 ------------------------ --



-- ------------------------ dashboard模块 ------------------------ --


-- ------------------------ 系统管理模块 ------------------------ --

-- 工作任务配置表
DROP TABLE IF EXISTS `job_settings`;
CREATE TABLE `job_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `workspace` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '工作目录',
  `job_timeout` int(11) NOT NULL DEFAULT '0' COMMENT '作业超时时间(秒)：0表示不超时',
  `idle_timeout` int(11) NOT NULL DEFAULT '0' COMMENT '作业无响应时间(秒)：0表示不超时',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工作任务设置表';

-- 环境变量
DROP TABLE IF EXISTS `environment_variable`;
CREATE TABLE `environment_variable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '变量名称',
  `value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '变量值',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='环境变量管理表';


-- --------------- 待定 --------------- --

-- 团队管理表
DROP TABLE IF EXISTS `team`;
CREATE TABLE `team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '团队名称',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='团队管理表';

-- 团队成员表
DROP TABLE IF EXISTS `team_users`;
CREATE TABLE `team_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) DEFAULT NULL COMMENT '团队id',
  `user_id` int(11) NOT NULL DEFAULT 0 COMMENT '用户id',
  PRIMARY KEY (`id`),
  KEY `team_id` (`team_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='团队成员表';

-- --------------- 待定 --------------- --

-- ------------------------ 系统管理模块 ------------------------ --

-- project 表增加 project_type 字段
alter table `project` add `project_type` varchar(30) NOT NULL DEFAULT '' COMMENT '项目类型：git-Git项目；svn-svn项目；playbook-playbook';

-- project 增加 playbook字段
alter table `project` add `playbook` text COMMENT 'playbook';

-- -------------- 3月20号新增

-- host_source表
DROP TABLE IF EXISTS `host_source`;
CREATE TABLE `host_source` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `inventory_id` int(11) DEFAULT NULL COMMENT 'inventory id',
  `source_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'project' COMMENT '来源类型:project-自动化项目；restapi-Rest API；script-脚本；aliyun_ecs-阿里云ECS',
  `project_id` int(11) DEFAULT NULL COMMENT '自动化项目ID',
  `host_file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '主机文件',
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'API地址',
  `method` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '请求方式:get-GET;post-POST;put-PUT;patch-PATCH',
  `header` text COMMENT '头信息',
  `params` text COMMENT '参数模板',
  `source_script` text COMMENT '脚本内容',
  PRIMARY KEY (`id`),
  UNIQUE KEY `inventory_source` (`inventory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='主机来源表';


-- --------------- 3月21号新增
alter table `project` add `credential_id` int(11) DEFAULT NULL COMMENT '凭据ID';

-- --------------- 3月24号新增
alter table `workflow_node` add `forks` int(11) NOT NULL DEFAULT '0' COMMENT 'forks';
alter table `workflow_node` add `limit` text COLLATE utf8mb4_unicode_ci COMMENT 'limit';
alter table `workflow_node` add `tags` text COLLATE utf8mb4_unicode_ci COMMENT 'tags';
alter table `workflow_node` add `skip_tags` text COLLATE utf8mb4_unicode_ci COMMENT 'skip tags';
alter table `workflow_node` add `verbosity` tinyint(3) NOT NULL DEFAULT '0' COMMENT 'Debug级别：0-Normal；1-Verbose；2-More Verbose；3-Debug；4-Connection Debug';
alter table `workflow_node` add `variables` text COLLATE utf8mb4_unicode_ci COMMENT '扩展参数';
alter table `workflow_node` add `become_enabled` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否允许切换用户:0-否；1-是';
alter table `workflow_node` add `diff_mode` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否使用diff模块:0-否；1-是';
alter table `workflow_node` add `force_handlers` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否强制运行handlers任务:0-否；1-是';
alter table `workflow_node` add `start_at_task` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '开始任务';

alter table `credential` add `vault_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Vault密码';
alter table `credential` add `vault_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Vault Id';

-- --------------- 3月27号新增
alter table `project` drop column `user_name`;
alter table `project` drop column `password`;

-- --------------- 4月2号新增
alter table `job` add `module` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '模块';

-- 模块为单选框：command, shell, yum, apt, apt_key, apt_repository, apt_rpm, service, group, user, mount, ping, selinux, setup, win_ping, win_service, win_updates, win_group, win_user

alter table `job` add `arguments` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '模块参数';

-- --------------- 4月8号新增
alter table `workflow_node` add `use_node_params` tinyint(3) NOT NULL DEFAULT '0' COMMENT '使用节点参数：0-否；1-是';

alter table `credential` add `key_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Key Id';
alter table `credential` add `key_secret` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Key Secret';

alter table `host_source` add `credential_id` int(11) DEFAULT NULL COMMENT '凭据Id';

-- ---------------- 4月12号新增
alter table `project` change `git` `repository_url` varchar(500) COLLATE utf8mb4_unicode_ci not null DEFAULT '' COMMENT '项目地址';
alter table `project` add `revision` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Revision';

alter table `host_source` add `regions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '地域';

-- ---------------- 4月16号新增
alter table `job` add `node_id` int(11) DEFAULT NULL COMMENT '节点id';


-- ---------------- 4月22号新增
alter table `project` add `vault_credential_id` int(11) DEFAULT NULL COMMENT 'Vault凭据';


-- ---------------- 4月26号新增
alter table `workflow_node` modify `bind_template_id` int(11) DEFAULT NULL COMMENT '绑定模板id';

-- ---------------- 4月29号新增
alter table `job_settings` add `keep_days` int(11) NOT NULL DEFAULT 180 COMMENT '日志保存天数(0表示不清理)';

-- ---------------- 4月30号新增
alter table `workflow_line` add UNIQUE KEY `node_next_node` (`node_id`, `next_node_id`);

-- ---------------- 5月05号新增
alter table `workflow_node` add KEY `template_id` (`template_id`);

alter table `workflow_node` add KEY `bind_template_id` (`bind_template_id`);

alter table `workflow_line` add KEY `node_id` (`node_id`);

alter table `workflow_line` add KEY `next_node_id` (`next_node_id`);


-- ---------------- 5月08号新增
alter table `schedule` drop column `timezone`;

alter table `job` add KEY `finish_time` (`finish_time`);

alter table `job` add KEY `start_time` (`start_time`);

alter table `job` add KEY `job_id` (`job_id`);

alter table `job` add KEY `template_id` (`template_id`);

alter table `job` add KEY `cuser` (`cuser`);


-- ---------------- 5月09号新增

-- ------------------------ project模块 ------------------------ --

-- 主机清单用户权限表
DROP TABLE IF EXISTS `inventory_user_permissions`;
CREATE TABLE `inventory_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 0 COMMENT '用户id',
  `data_id` int(11) NOT NULL DEFAULT 0 COMMENT '主机清单id',
  `permission` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限：read-只读；write-读写；admin-管理',
  PRIMARY KEY (`id`),
  KEY `inventory_permission` (`permission`),
  KEY `data_id` (`data_id`),
  KEY `user_id` (`user_id`),
  UNIQUE KEY `inventory_user_data_id` (`user_id`, `data_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='主机清单用户权限表';

-- 主机清单团队权限表
DROP TABLE IF EXISTS `inventory_team_permissions`;
CREATE TABLE `inventory_team_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL DEFAULT 0 COMMENT '团队id',
  `data_id` int(11) NOT NULL DEFAULT 0 COMMENT '主机清单id',
  `permission` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限：read-只读；write-读写；admin-管理',
  PRIMARY KEY (`id`),
  KEY `inventory_team_permission` (`permission`),
  KEY `data_id` (`data_id`),
  KEY `team_id` (`team_id`),
  UNIQUE KEY `inventory_team_data_id` (`team_id`, `data_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='主机清单团队权限表';

-- ------------------------ project模块 ------------------------ --

-- 凭据表、项目表、主机清单表、模板表、计划任务表增加创建用户字段

alter table `credential` add cuser int(11) NOT NULL DEFAULT 0 COMMENT '创建用户';

alter table `inventory` add cuser int(11) NOT NULL DEFAULT 0 COMMENT '创建用户';

alter table `project` add cuser int(11) NOT NULL DEFAULT 0 COMMENT '创建用户';

alter table `template` add cuser int(11) NOT NULL DEFAULT 0 COMMENT '创建用户';

alter table `schedule` add cuser int(11) NOT NULL DEFAULT 0 COMMENT '创建用户';

-- ---------------- 5月10号新增

-- ------------------------ project模块 ------------------------ --
-- 凭据用户权限表
DROP TABLE IF EXISTS `credential_user_permissions`;
CREATE TABLE `credential_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 0 COMMENT '用户id',
  `data_id` int(11) NOT NULL DEFAULT 0 COMMENT '凭据id',
  `permission` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限：read-只读；write-读写；admin-管理',
  PRIMARY KEY (`id`),
  KEY `credential_permission` (`permission`),
  KEY `data_id` (`data_id`),
  KEY `user_id` (`user_id`),
  UNIQUE KEY `credential_user_data_id` (`user_id`, `data_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='凭据用户权限表';

-- 凭据团队权限表
DROP TABLE IF EXISTS `credential_team_permissions`;
CREATE TABLE `credential_team_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL DEFAULT 0 COMMENT '团队id',
  `data_id` int(11) NOT NULL DEFAULT 0 COMMENT '凭据id',
  `permission` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限：read-只读；write-读写；admin-管理',
  PRIMARY KEY (`id`),
  KEY `credential_team_permission` (`permission`),
  KEY `data_id` (`data_id`),
  KEY `team_id` (`team_id`),
  UNIQUE KEY `credential_team_data_id` (`team_id`, `data_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='凭据团队权限表';

-- 项目用户权限表
DROP TABLE IF EXISTS `project_user_permissions`;
CREATE TABLE `project_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 0 COMMENT '用户id',
  `data_id` int(11) NOT NULL DEFAULT 0 COMMENT '项目id',
  `permission` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限：read-只读；write-读写；admin-管理',
  PRIMARY KEY (`id`),
  KEY `project_permission` (`permission`),
  KEY `data_id` (`data_id`),
  KEY `user_id` (`user_id`),
  UNIQUE KEY `project_user_data_id` (`user_id`, `data_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='项目用户权限表';

-- 项目团队权限表
DROP TABLE IF EXISTS `project_team_permissions`;
CREATE TABLE `project_team_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL DEFAULT 0 COMMENT '团队id',
  `data_id` int(11) NOT NULL DEFAULT 0 COMMENT '项目id',
  `permission` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限：read-只读；write-读写；admin-管理',
  PRIMARY KEY (`id`),
  KEY `project_team_permission` (`permission`),
  KEY `data_id` (`data_id`),
  KEY `team_id` (`team_id`),
  UNIQUE KEY `project_team_data_id` (`team_id`, `data_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='项目团队权限表';

-- ------------------------ project模块 ------------------------ --

-- ------------------------ template模块 ------------------------ --

-- 模板用户权限表
DROP TABLE IF EXISTS `template_user_permissions`;
CREATE TABLE `template_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 0 COMMENT '用户id',
  `data_id` int(11) NOT NULL DEFAULT 0 COMMENT '模板id',
  `permission` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限：read-只读；write-读写；admin-管理',
  PRIMARY KEY (`id`),
  KEY `template_permission` (`permission`),
  KEY `data_id` (`data_id`),
  KEY `user_id` (`user_id`),
  UNIQUE KEY `template_user_data_id` (`user_id`, `data_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='模板用户权限表';

-- 模板团队权限表
DROP TABLE IF EXISTS `template_team_permissions`;
CREATE TABLE `template_team_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL DEFAULT 0 COMMENT '团队id',
  `data_id` int(11) NOT NULL DEFAULT 0 COMMENT '模板id',
  `permission` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限：read-只读；write-读写；admin-管理',
  PRIMARY KEY (`id`),
  KEY `template_team_permission` (`permission`),
  KEY `data_id` (`data_id`),
  KEY `team_id` (`team_id`),
  UNIQUE KEY `template_team_data_id` (`team_id`, `data_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='模板团队权限表';

-- ------------------------ template模块 ------------------------ --

-- ------------------------ job模块 ------------------------ --

-- 计划任务用户权限表
DROP TABLE IF EXISTS `schedule_user_permissions`;
CREATE TABLE `schedule_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 0 COMMENT '用户id',
  `data_id` int(11) NOT NULL DEFAULT 0 COMMENT '计划任务id',
  `permission` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限：read-只读；write-读写；admin-管理',
  PRIMARY KEY (`id`),
  KEY `schedule_permission` (`permission`),
  KEY `data_id` (`data_id`),
  KEY `user_id` (`user_id`),
  UNIQUE KEY `schedule_user_data_id` (`user_id`, `data_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='计划任务用户权限表';

-- 计划任务团队权限表
DROP TABLE IF EXISTS `schedule_team_permissions`;
CREATE TABLE `schedule_team_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL DEFAULT 0 COMMENT '团队id',
  `data_id` int(11) NOT NULL DEFAULT 0 COMMENT '计划任务id',
  `permission` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '权限：read-只读；write-读写；admin-管理',
  PRIMARY KEY (`id`),
  KEY `schedule_team_permission` (`permission`),
  KEY `data_id` (`data_id`),
  KEY `team_id` (`team_id`),
  UNIQUE KEY `schedule_team_data_id` (`team_id`, `data_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='计划任务团队权限表';

-- ------------------------ job模块 ------------------------ --
alter table `dingtalk_setting` add name varchar(255) NOT NULL DEFAULT '' UNIQUE COMMENT '名称';

alter table `email_setting` add name varchar(255) NOT NULL DEFAULT '' UNIQUE COMMENT '名称';

alter table `notification` add channel_id int(11)  COMMENT '渠道ID';


-- ---- 6月14号新增
DROP TABLE IF EXISTS `ansible_module`;
CREATE TABLE `ansible_module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '模块名称',
  `weight` int(11) NOT NULL DEFAULT 0 COMMENT '显示权重(高的在前面)',
  `comment` text COLLATE utf8mb4_unicode_ci COMMENT '模块描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `module_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='模块管理';

CREATE TABLE `qiye_weixin_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `agent_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Agent ID',
  `corpid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Corp ID',
  `corpsecret` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Corp Secret',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='企业微信设置表'

alter table `job` add schedule_id int(11) DEFAULT NULL COMMENT '计划任务ID';
alter table `job` add ctime bigint(20) NOT NULL DEFAULT 0 COMMENT '创建时间';
alter table `job` add KEY `create_time` (`ctime`);
alter table `job` modify `module` varchar(100) NOT NULL DEFAULT '' COMMENT '模块';

-- ---- 6月18号新增
DROP TABLE IF EXISTS `tags`;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'tag',
  `weight` int(11) NOT NULL DEFAULT 0 COMMENT '显示权重(高的在前面)',
  `comment` text COLLATE utf8mb4_unicode_ci COMMENT 'tag描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tag` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='tag管理';

