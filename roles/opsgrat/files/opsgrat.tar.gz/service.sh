#!/bin/bash
basedir=/app/opsgrat
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/lib:.

listen="0.0.0.0:8007"
arg=$1
env=$2
process=`ps -ef|grep uwsgi|grep $listen|grep opsgrat |grep -v grep|wc -l`
case "$arg" in
  'status')
    if [ $process -ge "1" ];then
       echo ""
       echo "opsgrat is running..."
       echo ""
       ps -ef|grep uwsgi|grep opsgrat|grep -v grep
    else
       echo ""
       echo "opsgrat is not run!"
       echo ""
    fi
  ;;
  'start')
    if [ $process -ge "1" ];then
       echo " opsgrat is already run!"
    else
       if [ $env ]; then
         rm -f $basedir/opsgrat/configs.py
         cp $basedir/opsgrat/configs_$env.py $basedir/opsgrat/configs.py
       fi
       nohup uwsgi --http $listen --chdir $basedir --wsgi-file opsgrat/wsgi.py --static-map /static=$basedir/static --master --processes 2 --threads 10 1>/dev/null 2>&1 &
       sleep 3
       process=`ps -ef|grep uwsgi|grep $listen|grep opsgrat |grep -v grep|wc -l`
       if [ $process -ge "1" ];then
          echo "opsgrat start success!"
          echo ""
       else
          echo "opsgrat start fail!"
          echo ""
       fi
    fi
  ;;
  'stop')
    if [ $process -le "1" ];then
       echo "opsgrat is not running!"
    else
       ps -ef|grep uwsgi|grep $listen|grep -i -E "opsgrat"|grep -v -E "vi|grep"|awk '{print $2}' |while read line; do kill -9 $line; echo "opsgrat processes id $line been stop"; done
    fi
  ;;
  'log')
    tail -f opsgrat.out
  ;;
  '--help')
    echo "opsgrat help:"
    echo "===================================================================="
    echo "start        Start opsgrat server; Command: #sh service.sh start"
    echo "stop         Stop opsgrat server; Command: #sh service.sh stop"
    echo "status       Check opsgrat run status; Command: #sh service.sh status"
    echo "log          Check opsgrat run log; Command: #sh service.sh log"
  ;;
  *)
    echo "Please input  --help to read the help info."
  ;;
esac
exit 0
