#!/bin/bash

# 收集静态文件
python3 manage.py collectstatic

rm -fR static
mv staticfile static

# 编译base.py
cd utils
python3 setup.py build_ext
cp build/lib.*/utils/base.* base.so
rm -fR build
rm -f base.c
rm -f base.py

# 编译licensecheck.py
cd common
python3 setup.py build_ext
cp build/lib.*/utils/common/licensecheck.* licensecheck.so
rm -fR build
rm -f licensecheck.c
rm -f licensecheck.py

# 编译python
cd ../../
python3 -m compileall . -b
find . -name "*.py" |grep -v 'configs.py' |grep -v 'wsgi.py' |xargs rm -rf
rm -f opsgrat/configs_prd.pyc
rm -fR .git

