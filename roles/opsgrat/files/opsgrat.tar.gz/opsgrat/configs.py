# -*- coding: utf-8 -*-

import os, logging

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

########################## db ##########################
DB_NAME = "opsgrat"
DB_USER = "root"
DB_PASSWORD = "root"
DB_HOST = "127.0.0.1"
DB_PORT = "3306"

# sso db
SSO_DB_NAME = "opsgrat_sso"
SSO_DB_USER = "root"
SSO_DB_PASSWORD = "root"
SSO_DB_HOST = "127.0.0.1"
SSO_DB_PORT = "3306"


########################## db ##########################


REDIS = {
    "HOST": "127.0.0.1",
    "PORT": 6379,
    "PASSWORD": ''
}

RABBIT_MQ = {
    "HOST": "",
    "PORT": 5672,
    "USER": "guest",
    "PASSWORD": 'guest',
}

# 系统名称和子系统名称对应
SYSTEM_NAME = 'OpsGrat'

# 日志目录
LOG = '/var/log/opsgrat'
logger = logging.getLogger('opsgrat')

DEBUG = True
