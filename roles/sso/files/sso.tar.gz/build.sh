#!/bin/bash

# 收集静态文件
python3 manage.py collectstatic

rm -fR static
mv staticfile static

# 编译python
python3 -m compileall . -b
find . -name "*.py" |grep -v 'configs.py' |grep -v 'wsgi.py' |xargs rm -rf



