-- MySQL dump 10.13  Distrib 5.7.12, for osx10.11 (x86_64)
--
-- Host: localhost    Database: opsgrat_sso
-- ------------------------------------------------------
-- Server version	5.7.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_default_group`
--

DROP TABLE IF EXISTS `auth_default_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_default_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_default_group`
--

LOCK TABLES `auth_default_group` WRITE;
/*!40000 ALTER TABLE `auth_default_group` DISABLE KEYS */;
INSERT INTO `auth_default_group` VALUES (1,1);
/*!40000 ALTER TABLE `auth_default_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
INSERT INTO `auth_group` VALUES (2,'管理员权限组'),(1,'默认权限');
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_menus`
--

DROP TABLE IF EXISTS `auth_group_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `menu_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=950 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_menus`
--

LOCK TABLES `auth_group_menus` WRITE;
/*!40000 ALTER TABLE `auth_group_menus` DISABLE KEYS */;
INSERT INTO `auth_group_menus` VALUES (875,2,1),(876,2,2),(877,2,3),(878,2,4),(879,2,5),(880,2,9),(881,2,6),(882,2,7),(883,2,8),(884,2,10),(885,2,11),(886,2,119),(887,2,120),(889,2,180),(890,2,181),(891,2,182),(894,2,195),(895,2,197),(896,2,186),(897,2,187),(898,2,188),(901,2,196),(902,2,192),(903,2,193),(905,2,203),(907,2,198),(908,2,199),(909,1,1),(910,1,2),(912,1,180),(913,1,181),(914,1,182),(917,1,195),(918,1,197),(919,1,186),(920,1,187),(921,1,188),(924,1,196),(925,1,192),(926,1,203),(928,1,198),(929,1,199),(936,2,179),(937,1,179),(940,2,185),(941,2,184),(942,1,185),(943,1,184),(944,2,191),(945,2,190),(946,1,191),(947,1,190),(948,2,205),(949,2,192);
/*!40000 ALTER TABLE `auth_group_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_menu`
--

DROP TABLE IF EXISTS `auth_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `name` varchar(120) DEFAULT NULL,
  `path` varchar(360) DEFAULT NULL,
  `tag` varchar(120) DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=206 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_menu`
--

LOCK TABLES `auth_menu` WRITE;
/*!40000 ALTER TABLE `auth_menu` DISABLE KEYS */;
INSERT INTO `auth_menu` VALUES (1,0,'SSO',NULL,'user',0),(2,1,'首页','/',NULL,0),(3,0,'用户管理',NULL,'users',0),(4,3,'用户管理','/user/',NULL,0),(5,3,'部门管理','/user/structure/',NULL,0),(6,0,'菜单管理',NULL,'list',0),(7,6,'菜单管理','/user/menu/',NULL,0),(8,6,'子系统管理','/user/navigation/',NULL,0),(9,3,'角色管理','/user/group/menu/',NULL,0),(10,0,'日志管理',NULL,'file-text',0),(11,10,'日志查看','/changelog/changelog/',NULL,0),(119,0,'系统设置',NULL,'cog',0),(120,119,'基本设置','/user/ldap/',NULL,0),(179,0,'资源管理',NULL,'book',8000),(180,179,'凭据管理','/project/credential/',NULL,0),(181,179,'自动化项目','/project/project/',NULL,0),(182,179,'主机清单','/project/inventory/',NULL,0),(184,0,'自动化管理',NULL,'clock-o',9000),(185,184,'计划任务','/job/schedule/',NULL,-1),(186,0,'通知管理',NULL,'bell',0),(187,186,'通知设置','/notification/notification/',NULL,0),(188,186,'渠道设置','/notification/channel/',NULL,0),(190,0,'模板管理',NULL,'sitemap',7000),(191,190,'作业模板','/template/template/',NULL,0),(192,0,'系统管理',NULL,'cog',0),(193,192,'作业设置','/system/jobsettings/',NULL,0),(195,184,'作业管理','/job/job/',NULL,0),(196,190,'工作流模板','/template/workflow/',NULL,0),(197,184,'批量命令','/job/batch/process/',NULL,0),(198,0,'Dashboard',NULL,'dashboard',10000),(199,198,'Dashboard','/dashboard/job/',NULL,0),(203,192,'团队管理','/system/team/',NULL,0),(205,192,'License','/system/license/import/',NULL,0);
/*!40000 ALTER TABLE `auth_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_navigation`
--

DROP TABLE IF EXISTS `auth_navigation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_navigation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `weight` int(11) NOT NULL,
  `icon` varchar(30) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `comment` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_navigation`
--

LOCK TABLES `auth_navigation` WRITE;
/*!40000 ALTER TABLE `auth_navigation` DISABLE KEYS */;
INSERT INTO `auth_navigation` VALUES (1,'SSO',-1,'user','http://127.0.0.1:8009/','单点登录系统'),(10,'OpsGrat',0,'rocket','http://127.0.0.1:8008/','自动化系统');
/*!40000 ALTER TABLE `auth_navigation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_navigation_menu`
--

DROP TABLE IF EXISTS `auth_navigation_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_navigation_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `navigation_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1150 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_navigation_menu`
--

LOCK TABLES `auth_navigation_menu` WRITE;
/*!40000 ALTER TABLE `auth_navigation_menu` DISABLE KEYS */;
INSERT INTO `auth_navigation_menu` VALUES (1113,10,179),(1114,10,180),(1115,10,181),(1116,10,182),(1117,10,184),(1118,10,185),(1119,10,195),(1120,10,197),(1121,10,186),(1122,10,187),(1123,10,188),(1126,10,196),(1127,10,192),(1128,10,193),(1129,10,203),(1131,10,198),(1132,10,199),(1133,1,1),(1134,1,2),(1135,1,3),(1136,1,4),(1137,1,5),(1138,1,9),(1139,1,6),(1140,1,7),(1141,1,8),(1142,1,10),(1143,1,11),(1144,1,119),(1145,1,120),(1146,10,191),(1147,10,190),(1148,10,205),(1149,10,192);
/*!40000 ALTER TABLE `auth_navigation_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can add group',2,'add_group'),(5,'Can change group',2,'change_group'),(6,'Can delete group',2,'delete_group'),(7,'Can add permission',3,'add_permission'),(8,'Can change permission',3,'change_permission'),(9,'Can delete permission',3,'delete_permission'),(10,'Can add user',4,'add_user'),(11,'Can change user',4,'change_user'),(12,'Can delete user',4,'delete_user'),(13,'Can add content type',5,'add_contenttype'),(14,'Can change content type',5,'change_contenttype'),(15,'Can delete content type',5,'delete_contenttype'),(16,'Can add session',6,'add_session'),(17,'Can change session',6,'change_session'),(18,'Can delete session',6,'delete_session'),(19,'Can add Token',7,'add_token'),(20,'Can change Token',7,'change_token'),(21,'Can delete Token',7,'delete_token'),(22,'Can add notification',8,'add_notification'),(23,'Can change notification',8,'change_notification'),(24,'Can delete notification',8,'delete_notification'),(25,'Can add token',9,'add_token'),(26,'Can change token',9,'change_token'),(27,'Can delete token',9,'delete_token'),(28,'Can add change log',10,'add_changelog'),(29,'Can change change log',10,'change_changelog'),(30,'Can delete change log',10,'delete_changelog'),(31,'Can add structure',11,'add_structure'),(32,'Can change structure',11,'change_structure'),(33,'Can delete structure',11,'delete_structure'),(34,'Can add menu',12,'add_menu'),(35,'Can change menu',12,'change_menu'),(36,'Can delete menu',12,'delete_menu'),(37,'Can add user profile',13,'add_userprofile'),(38,'Can change user profile',13,'change_userprofile'),(39,'Can delete user profile',13,'delete_userprofile'),(40,'Can add default group',14,'add_defaultgroup'),(41,'Can change default group',14,'change_defaultgroup'),(42,'Can delete default group',14,'delete_defaultgroup'),(43,'Can add group menu',15,'add_groupmenu'),(44,'Can change group menu',15,'change_groupmenu'),(45,'Can delete group menu',15,'delete_groupmenu'),(46,'Can add navigation',16,'add_navigation'),(47,'Can change navigation',16,'change_navigation'),(48,'Can delete navigation',16,'delete_navigation'),(49,'Can add navigation menu',17,'add_navigationmenu'),(50,'Can change navigation menu',17,'change_navigationmenu'),(51,'Can delete navigation menu',17,'delete_navigationmenu'),(52,'Can add structure user',18,'add_structureuser'),(53,'Can change structure user',18,'change_structureuser'),(54,'Can delete structure user',18,'delete_structureuser');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$120000$hkx2Ls11kjiv$Br/z3m1r3H/FSGTDW/0zaDTTikrKQf5kuyqNr1rezi8=','2019-06-06 02:12:41.439666',1,'admin','','超级管理员','admin@xx.com',1,1,'2018-07-11 12:54:08.085028');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
INSERT INTO `auth_user_groups` VALUES (22,1,2),(17,3,1),(18,16,1);
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authtoken_token`
--

DROP TABLE IF EXISTS `authtoken_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authtoken_token` (
  `key` varchar(40) NOT NULL,
  `created` datetime(6) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `authtoken_token_user_id_35299eff_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authtoken_token`
--

LOCK TABLES `authtoken_token` WRITE;
/*!40000 ALTER TABLE `authtoken_token` DISABLE KEYS */;
INSERT INTO `authtoken_token` VALUES ('7ec5c534cff717743857decf2b4f3ee3fb93b267','2019-05-16 01:07:57.700817',1);
/*!40000 ALTER TABLE `authtoken_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changelog`
--

DROP TABLE IF EXISTS `changelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changelog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(128) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `resource` varchar(60) DEFAULT NULL,
  `res_id` varchar(64) DEFAULT NULL,
  `action` varchar(30) DEFAULT NULL,
  `index` varchar(100) DEFAULT NULL,
  `message` longtext NOT NULL,
  `change_time` bigint(20) DEFAULT NULL,
  `ctime` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `changelog_resource_res_id_1bf7a634_idx` (`resource`,`res_id`),
  KEY `changelog_index_d414e7e2` (`index`),
  KEY `changelog_change_time_8ca57e24` (`change_time`),
  KEY `change_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changelog`
--

LOCK TABLES `changelog` WRITE;
/*!40000 ALTER TABLE `changelog` DISABLE KEYS */;
/*!40000 ALTER TABLE `changelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(2,'auth','group'),(3,'auth','permission'),(4,'auth','user'),(7,'authtoken','token'),(10,'changelog','changelog'),(5,'contenttypes','contenttype'),(6,'sessions','session'),(8,'sso','notification'),(9,'sso','token'),(14,'users','defaultgroup'),(15,'users','groupmenu'),(12,'users','menu'),(16,'users','navigation'),(17,'users','navigationmenu'),(11,'users','structure'),(18,'users','structureuser'),(13,'users','userprofile');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('045l67yv0x5np8cc6k8ktbw4717f9v48','OWIzMjI2YzFjNjY4NmYwOWY4MTI0ZWU1Mzg2ZDg2Y2MwOTgyM2IwZDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4MmY2ZjlkNjViMzNjZGYyNzZlY2EzOWJiYjdhYWQ4YWJiMjVlZmJkIiwibmF2aWQiOjEwfQ==','2019-06-19 04:36:42.705432'),('0g2jb7x3qhbjiv0unjiwccb6oj6as6ag','OWIzMjI2YzFjNjY4NmYwOWY4MTI0ZWU1Mzg2ZDg2Y2MwOTgyM2IwZDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4MmY2ZjlkNjViMzNjZGYyNzZlY2EzOWJiYjdhYWQ4YWJiMjVlZmJkIiwibmF2aWQiOjEwfQ==','2019-06-20 01:15:01.229126'),('0nsbo0b35r179e7rkhpfo7im63tm8a9o','OWIzMjI2YzFjNjY4NmYwOWY4MTI0ZWU1Mzg2ZDg2Y2MwOTgyM2IwZDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4MmY2ZjlkNjViMzNjZGYyNzZlY2EzOWJiYjdhYWQ4YWJiMjVlZmJkIiwibmF2aWQiOjEwfQ==','2019-06-17 05:43:24.497386'),('32gbzlk08nfqt8gfn9hcz56p6oi8go4u','ZjNhYjdjODg3NzRjMmZjZDNkNjljMTU5MDRiODcxN2EyMGNlMTBiMDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3ZGVjMzM3OGY5YTdlODNjMTcxNTZjOGQyMTI4MzIyMDk1NzUxY2YyIiwibmF2aWQiOjF9','2019-06-13 08:15:05.492810'),('4duaz8qc8e3ee6fu88utca9fvtpl3jx1','ZjNhYjdjODg3NzRjMmZjZDNkNjljMTU5MDRiODcxN2EyMGNlMTBiMDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3ZGVjMzM3OGY5YTdlODNjMTcxNTZjOGQyMTI4MzIyMDk1NzUxY2YyIiwibmF2aWQiOjF9','2019-06-11 09:10:59.577841'),('5jynihtw15g5ifyr8klar14t5xknhf7j','Y2RjZjZkZDgyMmQzZWRlZDM2Y2M5OTliY2EzMzYzZmY2YjhlNWFhNzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5NWNhODkyYzU4OTAxZTg5Y2RhZmI0YzQ0NjZmZDYwMGE5ZjEwYTBhIiwibmF2aWQiOjEwfQ==','2019-06-06 08:27:11.853302'),('6wmu3ygdd4d8gj21qnrw6xhutjseb38q','Y2RjZjZkZDgyMmQzZWRlZDM2Y2M5OTliY2EzMzYzZmY2YjhlNWFhNzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5NWNhODkyYzU4OTAxZTg5Y2RhZmI0YzQ0NjZmZDYwMGE5ZjEwYTBhIiwibmF2aWQiOjEwfQ==','2019-06-05 07:03:34.170185'),('a4f97p90j9g6oqtchdkyygekjoc759ix','OWIzMjI2YzFjNjY4NmYwOWY4MTI0ZWU1Mzg2ZDg2Y2MwOTgyM2IwZDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4MmY2ZjlkNjViMzNjZGYyNzZlY2EzOWJiYjdhYWQ4YWJiMjVlZmJkIiwibmF2aWQiOjEwfQ==','2019-06-20 02:14:43.134069'),('arni9dm1eoorpdrwz4x6atzt9x4qh97t','OWIzMjI2YzFjNjY4NmYwOWY4MTI0ZWU1Mzg2ZDg2Y2MwOTgyM2IwZDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4MmY2ZjlkNjViMzNjZGYyNzZlY2EzOWJiYjdhYWQ4YWJiMjVlZmJkIiwibmF2aWQiOjEwfQ==','2019-06-17 08:54:22.671780'),('bs43m1aqwbs9rzh8in7bi28coo5qca98','NDVjMjZiMTc2MTExNjIzMDU4YTdmYjZlNjIzMDcwMjU2MDQ4YzkyMDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3ZGVjMzM3OGY5YTdlODNjMTcxNTZjOGQyMTI4MzIyMDk1NzUxY2YyIn0=','2019-06-07 02:34:18.429179'),('doi7yak9f6hke1h3kkgtl04rhgh9o08g','Y2RjZjZkZDgyMmQzZWRlZDM2Y2M5OTliY2EzMzYzZmY2YjhlNWFhNzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5NWNhODkyYzU4OTAxZTg5Y2RhZmI0YzQ0NjZmZDYwMGE5ZjEwYTBhIiwibmF2aWQiOjEwfQ==','2019-06-12 06:29:33.666358'),('f8pbyv390aftzuqylqhb115r2qog7bmi','N2I5ZWRiMGY1NzA0MGQwZWIxMWZmZWY1ZDRmODhmZWMzMTIyZTQ3OTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlODdhM2JiY2JmNDMwMGNhMzRiMmFjMDIwZGNlNzZiZjliMWJlOWVjIn0=','2019-06-20 01:14:36.189891'),('hg3pu4qlzx3z1z6i30hzbsepw4dbfjpg','ZjNhYjdjODg3NzRjMmZjZDNkNjljMTU5MDRiODcxN2EyMGNlMTBiMDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3ZGVjMzM3OGY5YTdlODNjMTcxNTZjOGQyMTI4MzIyMDk1NzUxY2YyIiwibmF2aWQiOjF9','2019-06-07 05:58:54.162334'),('hhhe48cdvse2hgazckvwjd2xiq3jsmxh','NmFmOGJmNGQ4MzY3MWU0M2M2NTcwN2Q4ZDlmOTI1MDc2NTk0NWE4NTp7fQ==','2019-05-29 09:15:09.850311'),('i4rgsw0n81a7f9byi6v33lphdt3krrws','OWIzMjI2YzFjNjY4NmYwOWY4MTI0ZWU1Mzg2ZDg2Y2MwOTgyM2IwZDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4MmY2ZjlkNjViMzNjZGYyNzZlY2EzOWJiYjdhYWQ4YWJiMjVlZmJkIiwibmF2aWQiOjEwfQ==','2019-06-18 05:01:55.002738'),('ilhmswae2yg7das4ych8lo3uucyrxbo6','ZDQzZjM1NTA0ODUyYjMwYjBkMmIwZjRhNzg4ZGU5OWE0MWEwMWMyNTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlODdhM2JiY2JmNDMwMGNhMzRiMmFjMDIwZGNlNzZiZjliMWJlOWVjIiwibmF2aWQiOjF9','2019-06-19 03:05:49.936192'),('ixekavymj7smzc04s8k69qk8mroj931p','Y2RjZjZkZDgyMmQzZWRlZDM2Y2M5OTliY2EzMzYzZmY2YjhlNWFhNzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5NWNhODkyYzU4OTAxZTg5Y2RhZmI0YzQ0NjZmZDYwMGE5ZjEwYTBhIiwibmF2aWQiOjEwfQ==','2019-06-07 06:15:58.323948'),('knn1jhvhq3mb7yk1pcelsuhmzop4axpl','ZjNhYjdjODg3NzRjMmZjZDNkNjljMTU5MDRiODcxN2EyMGNlMTBiMDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3ZGVjMzM3OGY5YTdlODNjMTcxNTZjOGQyMTI4MzIyMDk1NzUxY2YyIiwibmF2aWQiOjF9','2019-06-13 08:42:36.541716'),('kpwvmq6961arikqmoj8p3m9551gqqwnc','ZDQzZjM1NTA0ODUyYjMwYjBkMmIwZjRhNzg4ZGU5OWE0MWEwMWMyNTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlODdhM2JiY2JmNDMwMGNhMzRiMmFjMDIwZGNlNzZiZjliMWJlOWVjIiwibmF2aWQiOjF9','2019-06-17 05:44:28.296797'),('n7ecfeyc4iy8alf0p8sd9i4p7jla4rdk','Y2RjZjZkZDgyMmQzZWRlZDM2Y2M5OTliY2EzMzYzZmY2YjhlNWFhNzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5NWNhODkyYzU4OTAxZTg5Y2RhZmI0YzQ0NjZmZDYwMGE5ZjEwYTBhIiwibmF2aWQiOjEwfQ==','2019-06-14 04:34:55.321589'),('nx4kwuf02exbpvpaaf0t2rf25efnge32','Y2RjZjZkZDgyMmQzZWRlZDM2Y2M5OTliY2EzMzYzZmY2YjhlNWFhNzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5NWNhODkyYzU4OTAxZTg5Y2RhZmI0YzQ0NjZmZDYwMGE5ZjEwYTBhIiwibmF2aWQiOjEwfQ==','2019-06-12 10:07:26.034241'),('o82q2bp8laqr9zyis2zbo8okaj1n2eko','ZjNhYjdjODg3NzRjMmZjZDNkNjljMTU5MDRiODcxN2EyMGNlMTBiMDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3ZGVjMzM3OGY5YTdlODNjMTcxNTZjOGQyMTI4MzIyMDk1NzUxY2YyIiwibmF2aWQiOjF9','2019-06-14 04:34:43.257138'),('ohvmqzr6asz74zw97nc5vouz68wzmi8c','ZDQzZjM1NTA0ODUyYjMwYjBkMmIwZjRhNzg4ZGU5OWE0MWEwMWMyNTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlODdhM2JiY2JmNDMwMGNhMzRiMmFjMDIwZGNlNzZiZjliMWJlOWVjIiwibmF2aWQiOjF9','2019-06-17 08:53:03.202811'),('pflrfyj8slyor1c9ghbp1rtbw5n6ssd8','Y2RjZjZkZDgyMmQzZWRlZDM2Y2M5OTliY2EzMzYzZmY2YjhlNWFhNzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5NWNhODkyYzU4OTAxZTg5Y2RhZmI0YzQ0NjZmZDYwMGE5ZjEwYTBhIiwibmF2aWQiOjEwfQ==','2019-06-13 00:56:20.567502'),('q4yj3agaqw7qyjnpw3fquxgll712tht4','ZDQzZjM1NTA0ODUyYjMwYjBkMmIwZjRhNzg4ZGU5OWE0MWEwMWMyNTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlODdhM2JiY2JmNDMwMGNhMzRiMmFjMDIwZGNlNzZiZjliMWJlOWVjIiwibmF2aWQiOjF9','2019-06-14 07:50:35.347990'),('qjdztwu0bhea7hdae6p7z8j7k34pqn21','Y2RjZjZkZDgyMmQzZWRlZDM2Y2M5OTliY2EzMzYzZmY2YjhlNWFhNzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5NWNhODkyYzU4OTAxZTg5Y2RhZmI0YzQ0NjZmZDYwMGE5ZjEwYTBhIiwibmF2aWQiOjEwfQ==','2019-06-13 06:05:07.542174'),('seirk3f14fbbl9r3la6eg9hjnb0722bd','N2I5ZWRiMGY1NzA0MGQwZWIxMWZmZWY1ZDRmODhmZWMzMTIyZTQ3OTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlODdhM2JiY2JmNDMwMGNhMzRiMmFjMDIwZGNlNzZiZjliMWJlOWVjIn0=','2019-06-18 04:45:38.989859'),('vqpj5vu3spncxh11afyqnuoxma6s6d4n','ZDQzZjM1NTA0ODUyYjMwYjBkMmIwZjRhNzg4ZGU5OWE0MWEwMWMyNTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlODdhM2JiY2JmNDMwMGNhMzRiMmFjMDIwZGNlNzZiZjliMWJlOWVjIiwibmF2aWQiOjF9','2019-06-20 02:08:36.974991'),('x51mevtz3jt66dseavifei617fnn1fqy','Y2RjZjZkZDgyMmQzZWRlZDM2Y2M5OTliY2EzMzYzZmY2YjhlNWFhNzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5NWNhODkyYzU4OTAxZTg5Y2RhZmI0YzQ0NjZmZDYwMGE5ZjEwYTBhIiwibmF2aWQiOjEwfQ==','2019-06-11 09:11:08.417935'),('yej25itrncqu51up010ym7sb36a93uhw','Y2RjZjZkZDgyMmQzZWRlZDM2Y2M5OTliY2EzMzYzZmY2YjhlNWFhNzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5NWNhODkyYzU4OTAxZTg5Y2RhZmI0YzQ0NjZmZDYwMGE5ZjEwYTBhIiwibmF2aWQiOjEwfQ==','2019-06-07 07:08:29.531252'),('z0n5zm29pfie3tfd1sytf6u9j4b5nu3s','NDVjMjZiMTc2MTExNjIzMDU4YTdmYjZlNjIzMDcwMjU2MDQ4YzkyMDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3ZGVjMzM3OGY5YTdlODNjMTcxNTZjOGQyMTI4MzIyMDk1NzUxY2YyIn0=','2019-06-05 02:26:49.207349');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `public_notification`
--

DROP TABLE IF EXISTS `public_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `public_notification` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `msg_key` varchar(64) NOT NULL,
  `message` longtext,
  `user_id` int(11) NOT NULL,
  `ctime` bigint(20) NOT NULL,
  `expirtime` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `public_notification`
--

LOCK TABLES `public_notification` WRITE;
/*!40000 ALTER TABLE `public_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `public_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sso_ldap`
--

DROP TABLE IF EXISTS `sso_ldap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sso_ldap` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_uri` varchar(255) NOT NULL DEFAULT '' COMMENT 'LDAP地址',
  `bind_dn` varchar(255) NOT NULL DEFAULT '' COMMENT '绑定DN',
  `password` varchar(255) NOT NULL DEFAULT '' COMMENT '密码',
  `user_ou` text COMMENT '用户OU',
  `user_filter` varchar(255) NOT NULL DEFAULT '(&(objectClass=person)(sAMAccountName=%(user)s))' COMMENT '用户过滤',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '状态：0-启用；1-禁用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sso_ldap`
--

LOCK TABLES `sso_ldap` WRITE;
/*!40000 ALTER TABLE `sso_ldap` DISABLE KEYS */;
/*!40000 ALTER TABLE `sso_ldap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sso_token`
--

DROP TABLE IF EXISTS `sso_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sso_token` (
  `token_key` varchar(64) NOT NULL,
  `user_id` int(11) NOT NULL,
  `expire_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`token_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sso_token`
--

LOCK TABLES `sso_token` WRITE;
/*!40000 ALTER TABLE `sso_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `sso_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structure`
--

DROP TABLE IF EXISTS `structure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `leader_id` int(11) NOT NULL,
  `comment` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_name` (`full_name`)
) ENGINE=InnoDB AUTO_INCREMENT=63601178 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structure`
--

LOCK TABLES `structure` WRITE;
/*!40000 ALTER TABLE `structure` DISABLE KEYS */;
/*!40000 ALTER TABLE `structure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structure_user`
--

DROP TABLE IF EXISTS `structure_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structure_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structure_user`
--

LOCK TABLES `structure_user` WRITE;
/*!40000 ALTER TABLE `structure_user` DISABLE KEYS */;
INSERT INTO `structure_user` VALUES (23,123,15),(24,123,16),(25,123,4),(26,123,3),(27,63601177,4),(28,63601177,14),(29,63601177,3),(30,63601177,13),(31,63601175,16),(32,63601175,4),(33,63601177,15);
/*!40000 ALTER TABLE `structure_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_profile`
--

DROP TABLE IF EXISTS `user_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cell_phone` varchar(60) NOT NULL,
  `user_id` int(11) NOT NULL,
  `extend_user_id` varchar(100) NOT NULL DEFAULT '' COMMENT '第三方用户ID',
  `remark` text COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `user_profile_user_id_8fdce8e2_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_profile`
--

LOCK TABLES `user_profile` WRITE;
/*!40000 ALTER TABLE `user_profile` DISABLE KEYS */;
INSERT INTO `user_profile` VALUES (1,'',1,'',''),(3,'',3,'',''),(4,'',4,'',''),(13,'',13,'','');
/*!40000 ALTER TABLE `user_profile` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-06-06 13:23:32
