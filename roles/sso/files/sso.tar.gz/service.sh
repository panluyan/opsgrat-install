#!/bin/bash
basedir=/app/sso
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/lib:.

listen="0.0.0.0:8001"
arg=$1
process=`ps -ef|grep uwsgi|grep $listen|grep sso |grep -v grep|wc -l`
case "$arg" in
  'status')
    if [ $process -ge "1" ];then
       echo ""
       echo "sso is running..."
       echo ""
       ps -ef|grep uwsgi|grep sso|grep -v grep
    else
       echo ""
       echo "sso is not run!"
       echo ""
    fi
  ;;
  'start')
    if [ $process -ge "1" ];then
       echo " sso is already run!"
    else
       runuser -l deploy -c "nohup uwsgi --http $listen --chdir $basedir --wsgi-file sso/wsgi.py --static-map /static=$basedir/static --master --processes 2 --threads 10 1>/dev/null 2>&1 &"
       sleep 3
       process=`ps -ef|grep uwsgi|grep $listen|grep sso |grep -v grep|wc -l`
       if [ $process -ge "1" ];then
          echo "sso start success!"
          echo ""
       else
          echo "sso start fail!"
          echo ""
       fi
    fi
  ;;
  'stop')
    if [ $process -le "1" ];then
       echo "sso is not running!"
    else
       ps -ef|grep uwsgi|grep $listen|grep -i -E "sso"|grep -v -E "vi|grep"|awk '{print $2}' |while read line; do kill -9 $line; echo "sso processes id $line been stop"; done
       #killall python uwsgi
    fi
  ;;
  'log')
    tail -f sso.out
  ;;
  '--help')
    echo "sso help:"
    echo "===================================================================="
    echo "start        Start sso server; Command: #sh service.sh start"
    echo "stop         Stop sso server; Command: #sh service.sh stop"
    echo "status       Check sso run status; Command: #sh service.sh status"
    echo "log          Check sso run log; Command: #sh service.sh log"
  ;;
  *)
    echo "Please input  --help to read the help info."
  ;;
esac
exit 0
